/**
 * Fig. 2.4: Welcome3.java <br>
 * Printing multiple lines with a single statement.
 * 
 * @author Deitel & Associates, Inc.
 */
public class Welcome3 {
	/**
	 * main method begins execution of Java application
	 */
	public static void main(String[] args) {  
		System.out.println( "Welcome\nto\nJava\nProgramming!" );
	} // end main method
} // end class

