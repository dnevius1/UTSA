/**
 * Fig. 2.1: Welcome1.java <br>
 * Text-printing program.
 * 
 * @author Deitel & Associates, Inc.
 */

public class Welcome1 {
	/**
	 * main method begins execution of Java application
	 */
	public static void main(String[] args) {
		System.out.println( "Welcome to Java Programming!" );
	} // end main method
} // end class
