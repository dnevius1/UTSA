/**
 * Fig. 2.6: Welcome4.java <br>
 * Displaying multiple lines with method System.out.printf.
 * 
 * @author Deitel & Associates, Inc.
 *
 */
public class Welcome4 {
	/**
	 * main method begins execution of Java application
	 */
	public static void main(String[] args) {
		System.out.printf( "%s\n%s\n", 
				"Welcome to", "Java Programming!" );
	} // end main method
} // end class
