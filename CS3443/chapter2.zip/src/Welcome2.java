/**
 * Fig. 2.3: Welcome2.java <br>
 * Printing a line of text with multiple statements
 * 
 * @author Deitel & Associates, Inc.
 */
public class Welcome2 {
	/**
	 * main method begins execution of Java application
	 */
	public static void main(String[] args) {
		System.out.print( "Welcome to " );
		System.out.println( "Java Programming!" );
	} // end main method
} // end class
