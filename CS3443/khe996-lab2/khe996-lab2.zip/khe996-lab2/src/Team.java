/**
 *Opens file containing all Avenger data to store information about individual Avengers in Avenger.java. 
 * Also stores the team name. Returns all data to be printed.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 2
 * Spring 2022
 */

import java.io.*;
import java.util.*;

public class Team{
	String tN;
	ArrayList<Avenger> aL=new ArrayList<Avenger>();
	
	
	//Constructor
	public Team(String tN) {
		
		this.tN = tN;
	}
	//Returns string containing the team name
	@Override
	public String toString() {
		String avengeStr="";
		for(Avenger str:aL)
			avengeStr+=str;
		return "Team " + tN + ":\n\n" + avengeStr ;
	}
	//Adds an avenger to the ArrayList of avengers
	public void addAvenger(Avenger a) {
		this.aL.add(a);
	}
	
	//Takes in Avenger data from file and calls Avenger class to store in appropriate variables. Sends data to addAvenger to add the avenger to the team/ArrayList.
	public void loadAvengers(String fn) throws IOException {
		//Create scanner to scan file
		Scanner sc= new Scanner(new File("C:\\Users\\Daniel\\eclipse-workspace\\khe996-lab2\\data\\"+fn));
		//parse using comma or new line char
		sc.useDelimiter(",|\\n");
		//temp variables
		String name;
		String alias;
		String gender;
		String weight;
		double weightDouble;
		String height;
		String hFt;
		String hIn;
		String bool;
		String currentLoc;
		boolean hasPow;
		while(sc.hasNext()) {
			name=sc.next();
			alias=sc.next();
			gender=sc.next();
			hFt=sc.next();
			hIn=sc.next();
			height=hFt +"."+hIn;
			weight=sc.next();
			weightDouble=Double.parseDouble(weight);
			bool=sc.next();
			if(bool.contains("T"))
				hasPow=true;
			else
				hasPow=false;
			currentLoc=sc.next();
			Avenger n= new Avenger(name, alias, gender, height, weightDouble, currentLoc, hasPow);
			addAvenger(n);
		}
	}
	//Getters and Setters
	public String gettN() {
		return tN;
	}

	public void settN(String tN) {
		this.tN = tN;
	}

	public ArrayList<Avenger> getaL() {
		return aL;
	}

	public void setaL(ArrayList<Avenger> aL) {
		this.aL = aL;
	}
	
}
