/**
 *Takes in and stores the information for a single Avenger
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 2
 * Spring 2022
 */

public class Avenger extends Person  {
	String alias;
	String gender;
	String height;
	double weight;
	String currentLoc;
	boolean hasPow;
	//Constructor
	public Avenger(String name, String alias, String gender, String height, double weight, String currentLoc, boolean hasPow) {
		super(name);
		this.alias = alias;
		this.gender = gender;
		this.height = height;
		this.weight = weight;
		this.hasPow = hasPow;
		this.currentLoc = currentLoc;
		
	}

	
	//Returns string containing the Avenger's traits
	@Override
	public String toString() {
		String yesNo="";
		if (hasPow)
			yesNo="Yes";
		else
			yesNo="No";
		height=height.replace(".","'");
		height+="\"";
		return "-"+ name + " (" + alias + ")\n\nSpecial abilities: " + yesNo + "\n\n" + gender + ", " + height +  ", " + weight + "lbs\n\nCurrent Location: " + currentLoc + "\n\n\n\n";
	}


	//Getters and Setters
	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getCurrentLoc() {
		return currentLoc;
	}

	public void setCurrentLoc(String currentLoc) {
		this.currentLoc = currentLoc;
	}

	public boolean isHasPow() {
		return hasPow;
	}

	public void setHasPow(boolean hasPow) {
		this.hasPow = hasPow;
	}
	
	
}
