/**
 *Abstract class that stores a person's name. Name usable in Avengers.java
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 2
 * Spring 2022
 */

public abstract class Person {
		String name;
		
		//Constructor
		public Person(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
}
