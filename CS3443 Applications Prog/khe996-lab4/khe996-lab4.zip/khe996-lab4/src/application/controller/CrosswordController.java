/**
 * Controller for the crossword page. Checks if the user's 
 * answers are correct and prints the correct answers for
 * the user. Also displays hints for user on page.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import application.model.Hint;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class CrosswordController {
	ArrayList<Hint> acrossList;
	ArrayList<Hint> downList;
    
	@FXML
    private AnchorPane crossPane;
    @FXML
    private TextArea acrossTxt;
    @FXML
    private TextArea downTxt;
    @FXML
    private Button homeButton;
    @FXML
    private Button checkAns;
    @FXML
    private Button showAns;
    @FXML
    private TextField in1;
    @FXML
    private TextField in2;
    @FXML
    private TextField in3;
    @FXML
    private TextField in4;
    @FXML
    private TextField in5;
    @FXML
    private TextField in6;
    @FXML
    private TextField in7;
    @FXML
    private TextField in8;
    @FXML
    private TextField in9;
    @FXML
    private TextField in10;
    @FXML
    private TextField in11;
    @FXML
    private TextField in12;
    @FXML
    private TextField in13;
    @FXML
    private TextField in14;
    @FXML
    private TextField in15;
    @FXML
    private TextField in16;
    @FXML
    private TextField in17;
    @FXML
    private TextField in18;
    @FXML
    private TextField in19;
    @FXML
    private TextField in20;
    @FXML
    private TextField in21;
    @FXML
    private TextField in22;
    @FXML
    private TextField in23;
    @FXML
    private TextField in24;
    @FXML
    private TextField in25;
    @FXML
    private TextField in26;
    /*Populates hints down.csv and across.csv into two ArrayLists to be printed
     * on screen*/
    public void initialize() throws IOException {
    	String fnA="across.csv";
    	String fnD="down.csv";
    	application.model.Crossword a=new application.model.Crossword();
    	application.model.Crossword d=new application.model.Crossword();
    	a.loadData(fnA);
    	acrossList = a.getHintList();
    	d.loadData(fnD);
    	downList = d.getHintList();
    	
    	acrossTxt.appendText("\n");
    	for (int i = 0; i < acrossList.size(); i++) {
    	acrossTxt.appendText(acrossList.get(i).getNumber()+". "+acrossList.get(i).getHint()+"\n");
    	}
    	downTxt.appendText("\n");
    	for (int i = 0; i < downList.size(); i++) {
    	downTxt.appendText(downList.get(i).getNumber()+". "+downList.get(i).getHint()+"\n");
    	}
    }
   
    /*Returns user to home screen*/
    @FXML
    void clickHome(ActionEvent event) throws IOException {
    	URL url = new File("src/Main.fxml").toURI().toURL();
		AnchorPane root = FXMLLoader.load(url);
		Scene scene = new Scene(root,800,800);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
        window.setScene(scene);
        window.show();
    }
    /*Uses the Hint ArrayLists to show the correct answers stored in 
     * answers section of each Hint*/
    @FXML
    void showAnswers(ActionEvent event) {
    	in1.setText(acrossList.get(0).getAnswer().substring(0,1));
    	in2.setText(acrossList.get(0).getAnswer().substring(1,2));
    	in3.setText(acrossList.get(0).getAnswer().substring(2,3));
    	in4.setText(acrossList.get(0).getAnswer().substring(3,4));
    	in5.setText(acrossList.get(0).getAnswer().substring(4,5));
    	in6.setText(downList.get(0).getAnswer().substring(1,2));
    	in7.setText(downList.get(3).getAnswer().substring(1,2));
    	in8.setText(acrossList.get(1).getAnswer().substring(0,1));
    	in9.setText(downList.get(3).getAnswer().substring(2,3));
    	in10.setText(acrossList.get(1).getAnswer().substring(2,3));
    	in11.setText(downList.get(4).getAnswer().substring(0,1));
    	in12.setText(downList.get(1).getAnswer().substring(0,1));
    	in13.setText(downList.get(3).getAnswer().substring(3,4));
    	in14.setText(downList.get(4).getAnswer().substring(1,2));
    	in15.setText(acrossList.get(2).getAnswer().substring(0,1));
    	in16.setText(acrossList.get(2).getAnswer().substring(1,2));
    	in17.setText(acrossList.get(2).getAnswer().substring(2,3));
    	in18.setText(acrossList.get(2).getAnswer().substring(3,4));
    	in19.setText(acrossList.get(2).getAnswer().substring(4,5));
    	in20.setText(acrossList.get(2).getAnswer().substring(5,6));
    	in21.setText(acrossList.get(2).getAnswer().substring(6,7));
    	in22.setText(acrossList.get(3).getAnswer().substring(0,1));
    	in23.setText(acrossList.get(3).getAnswer().substring(1,2));
    	in24.setText(acrossList.get(3).getAnswer().substring(2,3));
    	in25.setText(acrossList.get(3).getAnswer().substring(3,4));
    	in26.setText(downList.get(4).getAnswer().substring(3,4));
    }
    /*Checks user input in each box to check whether or not the user's
     * answers are correct. Displays incorrect input in red*/
    @FXML
    void checkAnswers(ActionEvent event) {
    	if (!in1.getText().equalsIgnoreCase(acrossList.get(0).getAnswer().substring(0,1))) 
    		in1.setStyle("-fx-text-fill: red;");
    	else
    		in1.setStyle("-fx-text-fill: black;");
    
    	if (!in2.getText().equalsIgnoreCase(acrossList.get(0).getAnswer().substring(1,2))) 
    		in2.setStyle("-fx-text-fill: red;");
    	else
    		in2.setStyle("-fx-text-fill: black;");
    	
    	if (!in3.getText().equalsIgnoreCase(acrossList.get(0).getAnswer().substring(2,3))) 
    		in3.setStyle("-fx-text-fill: red;");
    	else
    		in3.setStyle("-fx-text-fill: black;");
    	
    	if (!in4.getText().equalsIgnoreCase(acrossList.get(0).getAnswer().substring(3,4))) 
    		in4.setStyle("-fx-text-fill: red;");
    	else
    		in4.setStyle("-fx-text-fill: black;");
    	
    	if (!in5.getText().equalsIgnoreCase(acrossList.get(0).getAnswer().substring(4,5))) 
    		in5.setStyle("-fx-text-fill: red;");
    	else
    		in5.setStyle("-fx-text-fill: black;");
    	
    	if (!in6.getText().equalsIgnoreCase(downList.get(0).getAnswer().substring(1,2))) 
    		in6.setStyle("-fx-text-fill: red;");
    	else
    		in6.setStyle("-fx-text-fill: black;");
    	
    	if (!in7.getText().equalsIgnoreCase(downList.get(3).getAnswer().substring(1,2))) 
    		in7.setStyle("-fx-text-fill: red;");
    	else
    		in7.setStyle("-fx-text-fill: black;");
    	
    	if (!in8.getText().equalsIgnoreCase(acrossList.get(1).getAnswer().substring(0,1))) 
    		in8.setStyle("-fx-text-fill: red;");
    	else
    		in8.setStyle("-fx-text-fill: black;");
    	
    	if (!in9.getText().equalsIgnoreCase(downList.get(3).getAnswer().substring(2,3))) 
    		in9.setStyle("-fx-text-fill: red;");
    	else
    		in9.setStyle("-fx-text-fill: black;");
    	
    	if (!in10.getText().equalsIgnoreCase(acrossList.get(1).getAnswer().substring(2,3))) 
    		in10.setStyle("-fx-text-fill: red;");
    	else
    		in10.setStyle("-fx-text-fill: black;");
    	
    	if (!in11.getText().equalsIgnoreCase(downList.get(4).getAnswer().substring(0,1))) 
    		in11.setStyle("-fx-text-fill: red;");
    	else
    		in11.setStyle("-fx-text-fill: black;");
    	
    	if (!in12.getText().equalsIgnoreCase(downList.get(1).getAnswer().substring(0,1))) 
    		in12.setStyle("-fx-text-fill: red;");
    	else
    		in12.setStyle("-fx-text-fill: black;");
    	
    	if (!in13.getText().equalsIgnoreCase(downList.get(3).getAnswer().substring(3,4))) 
    		in13.setStyle("-fx-text-fill: red;");
    	else
    		in13.setStyle("-fx-text-fill: black;");
    	
    	if (!in14.getText().equalsIgnoreCase(downList.get(4).getAnswer().substring(1,2))) 
    		in14.setStyle("-fx-text-fill: red;");
    	else
    		in14.setStyle("-fx-text-fill: black;");
    	
    	if (!in15.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(0,1))) 
    		in15.setStyle("-fx-text-fill: red;");
    	else
    		in15.setStyle("-fx-text-fill: black;");
    	
    	if (!in16.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(1,2))) 
    		in16.setStyle("-fx-text-fill: red;");
    	else
    		in16.setStyle("-fx-text-fill: black;");
    	
    	if (!in17.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(2,3))) 
    		in17.setStyle("-fx-text-fill: red;");
    	else
    		in17.setStyle("-fx-text-fill: black;");
    	
    	if (!in18.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(3,4))) 
    		in18.setStyle("-fx-text-fill: red;");
    	else
    		in18.setStyle("-fx-text-fill: black;");
    	
    	if (!in19.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(4,5))) 
    		in19.setStyle("-fx-text-fill: red;");
    	else
    		in19.setStyle("-fx-text-fill: black;");
    	
    	if (!in20.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(5,6))) 
    		in20.setStyle("-fx-text-fill: red;");
    	else
    		in20.setStyle("-fx-text-fill: black;");
    	
    	if (!in21.getText().equalsIgnoreCase(acrossList.get(2).getAnswer().substring(6,7))) 
    		in21.setStyle("-fx-text-fill: red;");
    	else
    		in21.setStyle("-fx-text-fill: black;");
    	
    	if (!in22.getText().equalsIgnoreCase(acrossList.get(3).getAnswer().substring(0,1))) 
    		in22.setStyle("-fx-text-fill: red;");
    	else
    		in22.setStyle("-fx-text-fill: black;");
    	
    	if (!in23.getText().equalsIgnoreCase(acrossList.get(3).getAnswer().substring(1,2))) 
    		in23.setStyle("-fx-text-fill: red;");
    	else
    		in23.setStyle("-fx-text-fill: black;");
    	
    	if (!in24.getText().equalsIgnoreCase(acrossList.get(3).getAnswer().substring(2,3))) 
    		in24.setStyle("-fx-text-fill: red;");
    	else
    		in24.setStyle("-fx-text-fill: black;");
    	
    	if (!in25.getText().equalsIgnoreCase(acrossList.get(3).getAnswer().substring(3,4))) 
    		in25.setStyle("-fx-text-fill: red;");
    	else
    		in25.setStyle("-fx-text-fill: black;");
    	
    	if (!in26.getText().equalsIgnoreCase(downList.get(4).getAnswer().substring(3,4))) 
    		in26.setStyle("-fx-text-fill: red;");
    	else
    		in26.setStyle("-fx-text-fill: black;");
    }
}