/**
 * Controller for the main menu page. Contains methods
 * that handle the process of switching screens when 
 * user clicks on buttons.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.controller;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainController {

    @FXML
    private Button b2;

    @FXML
    private AnchorPane mainPane;

    @FXML
    private Button b1;
    /*Switching to the classifieds screen*/
    @FXML
    public void handle1(ActionEvent event) throws IOException {
    	URL url = new File("src/Classifieds.fxml").toURI().toURL();
		AnchorPane root = FXMLLoader.load(url);
		Scene scene = new Scene(root,800,800);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
        window.setScene(scene);
        window.show();
        
    }
    /*Switching to the crossword screen*/
    @FXML
    public void handle2(ActionEvent event) throws IOException {
    	URL url = new File("src/Crossword.fxml").toURI().toURL();
		AnchorPane root = FXMLLoader.load(url);
		Scene scene = new Scene(root,800,800);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
        window.setScene(scene);
        window.show();
    }

}



