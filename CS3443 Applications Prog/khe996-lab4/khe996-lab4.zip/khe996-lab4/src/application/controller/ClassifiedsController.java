/**
 * Controller for the classifieds page. Takes in 
 * listing of classifieds from file to display them
 * on the screen for the user.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import application.model.Advertisement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ClassifiedsController {
	@FXML
    private AnchorPane classPane;
    @FXML
    private Button home;
    @FXML
    private TextArea txt1;
    @FXML
    private TextArea txt2;
    @FXML
    private TextArea txt3;
    @FXML
    private TextArea txt4;
    @FXML
    private TextArea txt5;
    @FXML
    private TextArea txt6;
    @FXML
    private TextArea txt7;
    @FXML
    private TextArea txt8;
    @FXML
    private TextArea txt9;
    @FXML
    private TextArea txt10;
    @FXML
    private TextArea txt11;
    @FXML
    private TextArea txt12;
    @FXML
    private TextArea txt13;
    @FXML
    private TextArea txt14;
    @FXML
    private TextArea txt15;
    @FXML
    private TextArea txt16;
    /*Returns user to home screen*/
    @FXML
    public void handle1(ActionEvent event) throws IOException {
        	
        	URL url = new File("src/Main.fxml").toURI().toURL();
    		AnchorPane root = FXMLLoader.load(url);
    		Scene scene = new Scene(root,800,800);
            Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();// pane you are ON
            window.setScene(scene);
            window.show();
        }
    /*Displays ads upon entering screen*/
    @FXML
    public void initialize() throws IOException {
    	String fn="ads.csv";
    	application.model.Classifieds c=new application.model.Classifieds();
    	/*calls loadAds() function in Classifieds.java to grab ArrayList
    	 * populated from specified file*/
    	c.loadAds(fn);
    	ArrayList<Advertisement> s = c.getaL();
    	String job1 = "";
    	if (s.get(0).getIsFullTime() == false)
			job1+="(Part time)";
		else 
			job1+="(Full time)";
    	/*Prints information from ArrayList to text boxes on screen*/
    	txt1.appendText(s.get(0).getTitle());
    	txt2.appendText(job1);
   		txt3.appendText(s.get(0).getPhoneNm());
   		txt4.appendText(s.get(0).getName() + " " + s.get(0).getDate());
    		
   		String job2 = "";
    	if (s.get(1).getIsFullTime() == false)
			job2+="(Part time)";
		else 
			job2+="(Full time)";	
    	txt5.appendText(s.get(1).getTitle());
    	txt6.appendText(job2);
   		txt7.appendText(s.get(1).getPhoneNm());
   		txt8.appendText(s.get(1).getName() + " " + s.get(1).getDate());
    	
   		String job3 = "";
    	if (s.get(2).getIsFullTime() == false)
			job3+="(Part time)";
		else 
			job3+="(Full time)";	
    	txt9.appendText(s.get(2).getTitle());
    	txt10.appendText(job3);
   		txt11.appendText(s.get(2).getPhoneNm());
   		txt12.appendText(s.get(2).getName() + " " + s.get(2).getDate());
   		
   		String job4 = "";
    	if (s.get(3).getIsFullTime() == false)
			job4+="(Part time)";
		else 
			job4+="(Full time)";	
    	txt13.appendText(s.get(3).getTitle());
    	txt14.appendText(job4);
   		txt15.appendText(s.get(3).getPhoneNm());
   		txt16.appendText(s.get(3).getName() + " " + s.get(3).getDate());
    }
}

