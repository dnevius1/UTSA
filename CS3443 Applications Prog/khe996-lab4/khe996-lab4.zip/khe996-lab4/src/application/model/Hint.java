/**
 * Data type for ArrayList to store hints. 
 * Stores each section of CSV in variables.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.model;

public class Hint {
	String number;
	String hint;
	String answer;
	/*Constructor*/
	public Hint(String number, String hint, String answer) {
		super();
		this.number = number;
		this.hint = hint;
		this.answer = answer;
	}
	/*Getters and setters*/
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getHint() {
		return hint;
	}
	public void setHint(String hint) {
		this.hint = hint;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
}
