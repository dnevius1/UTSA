/**
 * Takes in file containing crossword hints
 * and creates an ArrayList to store them.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Crossword {
	ArrayList<Hint> hintList = new ArrayList<Hint>();
	/*Constructor*/
	public Crossword() {
		super();
	}
	public void storeHint(Hint a) {
		this.hintList.add(a);
		
	}
	/*Opens file with scanner to parse and store
	 * information into variables. Sends variables to 
	 * create a Hint, then stores in list*/
	public void loadData(String fn) throws IOException {
		Scanner sc= new Scanner(new File("data/"+fn));
		sc.useDelimiter(",|\\n");
		String number;
		String hint;
		String answer;
		while (sc.hasNext()) {
			number = sc.next();
			hint = sc.next();
			answer = sc.next();
			Hint a = new Hint(number, hint, answer);
			storeHint(a);
		}
	}
	/*Gettters and setters*/
	public ArrayList<Hint> getHintList() {
		return hintList;
	}
	public void setHintList(ArrayList<Hint> hintList) {
		this.hintList = hintList;
	}
}
