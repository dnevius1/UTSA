/**
 * Takes in file containing job ads and creates 
 * an ArrayList to store the ads.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.model;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Classifieds{
	ArrayList<Advertisement> aL=new ArrayList<Advertisement>();
	/*Constructor*/
	public Classifieds() {
		super();
	}
	/*Adds an Advertisement to the ArrayList*/
	public void storeAd(Advertisement a) {
		this.aL.add(a);
	}
	/*Opens file with scanner to parse and store
	 * information into variables. Sends variables to 
	 * create an Advertisement, then stores in list*/
	public void loadAds(String fn) throws IOException {
		Scanner sc= new Scanner(new File("data/"+fn));
		sc.useDelimiter(",|\\n");
		String title;
		String bool;
		Boolean isFullTime;
		String phoneNm;
		String name;
		String date;
		while (sc.hasNext()) {
			title=sc.next();
			bool=sc.next();
			if(bool.contains("Full"))
				isFullTime=true;
			else
				isFullTime=false;
			phoneNm=sc.next();
			name=sc.next();
			date=sc.next();
			Advertisement a = new Advertisement(title, isFullTime, phoneNm, name, date);
			storeAd(a);
		}
		
	}
	/*Getters and setters*/
	public ArrayList<Advertisement> getaL() {
		return aL;
	}

	public void setaL(ArrayList<Advertisement> aL) {
		this.aL = aL;
	}
}
