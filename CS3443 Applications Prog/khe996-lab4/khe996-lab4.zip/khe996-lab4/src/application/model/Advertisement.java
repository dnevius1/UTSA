/**
 * Data type for ArrayList to store ads. 
 * Stores each section of CSV in variables.
 * 
 * @author Daniel Nevius (khe996)
 * UTSA CS 3443 - Lab 4
 * Spring 2022
 */

package application.model;

public class Advertisement {
	String title;
	Boolean isFullTime;
	String phoneNm;
	String name;
	String date;
	/*Constructor*/
	public Advertisement(String title, Boolean isFullTime, String phoneNm, String name, String date) {
		super();
		this.title = title;
		this.isFullTime = isFullTime;
		this.phoneNm = phoneNm;
		this.name = name;
		this.date = date;
	}
	/*Getters and setters*/
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Boolean getIsFullTime() {
		return isFullTime;
	}
	public void setIsFullTime(Boolean isFullTime) {
		this.isFullTime = isFullTime;
	}
	public String getPhoneNm() {
		return phoneNm;
	}
	public void setPhoneNm(String phoneNm) {
		this.phoneNm = phoneNm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
