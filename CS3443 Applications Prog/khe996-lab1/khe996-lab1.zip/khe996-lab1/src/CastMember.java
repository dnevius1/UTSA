/* @author Daniel Nevius (khe996)
 * Stores the name, age and number of roles for each cast member.
 */
import java.util.Arrays;

public class CastMember extends Person {
	int numOfRoles;
	Role[] roles;
	
	
	//Constructor
	public CastMember(String name, int age, int numOfRoles) {
		super(name, age);
		this.numOfRoles = numOfRoles;
		roles = new Role[numOfRoles];
	}

	//Printing name, age and role of cast member
	@Override
	public String toString() {
		int n=0;
		String s="";
		for(n=0;n<numOfRoles;n++) {
			s+=roles[n];
		}
		return name+" ("+age+") as:\n"+ s;
	}


	int i=0;
	public void addRole(Role role) {
		this.roles[i]=role;
		i++;
	}
	//Getters and setters
	public int getNumOfRoles() {
		return numOfRoles;
	}

	public void setNumOfRoles(int numOfRoles) {
		this.numOfRoles = numOfRoles;
	}

	public Role[] getRoles() {
		return roles;
	}

	public void setRoles(Role[] roles) {
		this.roles = roles;
	}

}
