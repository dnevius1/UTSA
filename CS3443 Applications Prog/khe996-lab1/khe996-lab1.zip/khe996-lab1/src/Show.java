/* @author Daniel Nevius (khe996)
 * Stores show name, number of members and CastMember names
 */
import java.util.Arrays;

public class Show {
	String showName;
	int numOfMembers;
	CastMember members[];
	//Constructor
	public Show(String showName, int numOfMembers) {
		this.showName = showName;
		this.numOfMembers = numOfMembers;
		members = new CastMember[numOfMembers];
	}
	
	//Prints Show and amount of cast members
	@Override
	public String toString() {
		int n;
		String s="";
		for(n=0;n<numOfMembers;n++) {
			s+=members[n];
		}
		return "Show: " + showName + "\n" + numOfMembers + " cast members:\n" + s;
	}

	//Takes in CastMember to be added to array of members
	int i=0;
	public void addCastMember(CastMember CastMember) {
		this.members[i]=CastMember;
			i++;
	}
	//Getters and setters
	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public int getNumOfMembers() {
		return numOfMembers;
	}

	public void setNumOfMembers(int numOfMembers) {
		this.numOfMembers = numOfMembers;
	}

	public CastMember[] getMembers() {
		return members;
	}

	public void setMembers(CastMember[] members) {
		this.members = members;
	}
}
