/* @author Daniel Nevius (khe996)
 * Extends person to apply name and age to person's role
 */
public class Role extends Person {
	
	public Role(String name, int age) {
		super(name, age);
		
	}
}
