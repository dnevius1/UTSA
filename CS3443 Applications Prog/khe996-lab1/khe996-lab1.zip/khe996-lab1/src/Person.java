/* @author Daniel Nevius (khe996)
 * Abstract class that stores the name and age of each person, which is shared with CastMember and Role.
 */
public abstract class Person {
	String name;
	int age;
	//Constructor
	public Person(String name, int age) {
		//super();
		this.name = name;
		this.age = age;
	}
	//Printing name and age of person
	@Override
	public String toString() {
		return "\t- " + getName() + "(" + getAge() + ")\n";
	}
	//Getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
}
